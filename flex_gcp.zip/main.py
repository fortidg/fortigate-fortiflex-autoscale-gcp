"""This Module handles FortiFlex Entitlements for Autoscale VMs"""
import os
import json
import logging
import base64
import functions_framework
import requests
from time import sleep
from google.cloud import compute_v1
from google.cloud import storage
from google.cloud import firestore
from google.oauth2 import service_account

logger = logging.getLogger()
logger.setLevel(logging.INFO)
FORTIFLEX_API_BASE_URI = "https://support.fortinet.com/ES/api/fortiflex/v2/"
FORTICARE_AUTH_URI = "https://customerapiauth.fortinet.com/api/v1/oauth/token/"

COMMON_HEADERS = {"Content-type": "application/json", "Accept": "application/json"}

def requests_post(resource_url, json_body, headers, verify=True):
    """Requests Post"""

    logging.info(resource_url)
    logging.info(json_body)
    logging.info(headers)

    result = requests.post(resource_url, json=json_body, headers=headers, timeout=20, verify=verify)

    if result.ok:
        logging.info(result.content)
        return_value = json.loads(result.content)
    else:
        logging.info(result)
        return_value = None

    logging.info(result.content)
    return return_value


def get_key():
    """Get the service account key file from Cloud Storage"""

    try:
        # Initialize a Cloud Storage client
        client = storage.Client()

        # Get a reference to the Cloud Storage bucket
        bucket = client.bucket(os.environ.get("BUCKET_NAME"))

        # Get a reference to the service account key file
        blob = bucket.blob(os.environ.get("WORKSHOP_SERVICE_ACCOUNT"))

        # Download the key file to a temporary file
        key_file = "/tmp/key.json"
        blob.download_to_filename(key_file)
        print(key_file)
        return key_file
    except Exception as e:
        return f"Error while fetching service account: {str(e)}"


def get_credentials():
    """Get scoped service account credentials"""
    try:
        # Initialize a Cloud Storage client
        client = storage.Client()

        # Get a reference to the Cloud Storage bucket
        bucket = client.bucket(os.environ.get("BUCKET_NAME"))

        # Get a reference to the service account key file
        blob = bucket.blob(os.environ.get("WORKSHOP_SERVICE_ACCOUNT"))

        # Download the key file to a temporary file
        key_file = "/tmp/key.json"
        blob.download_to_filename(key_file)

        # Authenticate with the service account using the key file
        credentials = service_account.Credentials.from_service_account_file(key_file)
        return credentials
    except Exception as e:
        return f"Error while fetching service account: {str(e)}"


def get_ip(credentials, instance, project, zone):
    """Get Public IP of the VM"""

    client = compute_v1.InstancesClient(credentials=credentials)

    #Initialize request argument(s)
    request = compute_v1.GetInstanceRequest(
        instance=instance,
        project=project,
        zone=zone,
    )

    # Make the request
    response = client.get(request=request)
    pip = response.network_interfaces[0].access_configs[0].nat_i_p


    return pip

def fauth():
    """Authenticate with FortiFlex API"""

    flex_user = os.environ.get("FLEXUSER")
    flex_pass = os.environ.get("FLEXPASS")


    fauth_url = "https://customerapiauth.fortinet.com/api/v1/oauth/token/"
    headers = {'Content-Type' : 'application/json; charset=utf-8'}
    body = {
        "username": flex_user,
        "password": flex_pass,
        "client_id": "flexvm",
        "grant_type": "password"
    }


    ##This opens the api request and prints the entire thing
    try:
        response = requests.post(
        url=fauth_url,
        headers=headers,
        json=body,
        timeout=20
        )
        jsonresponse = response.json()
        token = jsonresponse['access_token']
        return token

    except requests.exceptions.RequestException as e:
        print(f'Request failed: {e}')
        return f'Request failed: {e}'

def entitlements_list(ftoken, config_id):
    """Retrieve FortiFlex Entitlements List - V2"""

    logging.info("--> Retrieve FortiFlex Entitlements...")

    uri = FORTIFLEX_API_BASE_URI + "entitlements/list"
    headers = COMMON_HEADERS.copy()
    headers["Authorization"] = f"Bearer {ftoken}"

    body = {"configId": config_id}

    results = requests_post(uri, body, headers)

    serial = None
    if results is not None:
        for item in results['entitlements']:
            if item["status"] == 'PENDING':
                serial = item['serialNumber']
                break
        if serial is None:
            for item in results['entitlements']:
                if item["status"] == 'STOPPED':
                    serial = item['serialNumber']
                    break


    return serial

def activate_flex_entitlement(ftoken, serial):
    """Activate FortiFlex Token - V2"""
    logging.info("--> Activate FortiFlex Token...")

    uri = FORTIFLEX_API_BASE_URI + "entitlements/reactivate"
    headers = COMMON_HEADERS.copy()
    headers["Authorization"] = f"Bearer {ftoken}"

    body = {"serialNumber": serial}

    results = requests_post(uri, body, headers)

    flextoken = None
    if results is not None:
        for item in results['entitlements']:
            flextoken = item['token']

    return flextoken

def new_flex_token(ftoken, serial):
    """Regenerate FortiFlex Token - V2"""
    logging.info("--> Regenerate FortiFlex Token...")

    uri = FORTIFLEX_API_BASE_URI + "entitlements/vm/token"
    headers = COMMON_HEADERS.copy()
    headers["Authorization"] = f"Bearer {ftoken}"

    body = {"serialNumber": serial}

    results = requests_post(uri, body, headers)

    flextoken = None
    if results is not None:
        for item in results['entitlements']:
            flextoken = item['token']
    return flextoken

#(function_name, project_id, region, new_env_vars)
def add_firestore_collection(key, documents):
    """create/add docuemnts to Firestore collection"""

    credentials = key
    collection_name = os.environ.get("COLLECTION_NAME")
    db = firestore.Client.from_service_account_json(credentials)

    # Reference to the new collection
    collection_ref = db.collection(collection_name)

    # Add documents to the collection
    for doc_id, doc_data in documents.items():
        collection_ref.document(doc_id).set(doc_data)

    return f"Collection '{collection_name}' added successfully."

def vmlicense_download(pubip, flextoken):
    """Send FortiFlex Entitlement Token to FortiGate VM"""
    print(f"Sleeping for 600 seconds")
    sleep(600)
    print(f"Done sleeping")
    logging.info("--> Send FortiFlex Entitlement Token to VM...")
    vm_api_key = os.environ.get("VM_API_KEY")
    port = os.environ.get("FORTIGATE_ADMIN_PORT")


    uri = "https://" + f"{pubip}:{port}/api/v2/monitor/system/vmlicense/download?token={flextoken}&access_token={vm_api_key}"

    body = {}

    verify_cert = False
    results = requests_post(uri, body, COMMON_HEADERS, verify_cert)

    return results

def get_firestore_document(key, instance):
    """Pull records from Firestore collection"""
    credentials = key
    document_id = instance
    collection_name = os.environ.get("COLLECTION_NAME")

    db = firestore.Client.from_service_account_json(credentials)

    # Reference to the document
    doc_ref = db.collection(collection_name).document(document_id)

    # Get the document
    serial = None
    doc = doc_ref.get()
    if doc.exists:
        serial = doc.to_dict()["serial"]
    return serial

def stop_flex_entitlement(ftoken, serial):
    """Activate FortiFlex Token - V2"""
    logging.info("--> Activate FortiFlex Token...")

    uri = FORTIFLEX_API_BASE_URI + "entitlements/stop"
    headers = COMMON_HEADERS.copy()
    headers["Authorization"] = f"Bearer {ftoken}"

    body = {"serialNumber": serial}

    results = requests_post(uri, body, headers)
    return results

def delete_firestore_document(key, instance):
    """delete Firestore document"""
    credentials = key
    document_id = instance
    collection_name = os.environ.get("COLLECTION_NAME")
    db = firestore.Client.from_service_account_json(credentials)

    # Reference to the document
    doc_ref = db.collection(collection_name).document(document_id)


    # Delete the document
    if doc_ref:
        doc_ref.delete()
    return f"Document '{document_id}' from collection '{collection_name}' deleted successfully."


def get_flex_configid(ftoken):
    """Get Flex Config Id from name - V2"""
    logging.info("--> Get FortiFlex Configid...")
    flex_prog_serial = os.environ.get("FLEX_PROG_SERIAL")
    uri = FORTIFLEX_API_BASE_URI + "configs/list"
    headers = COMMON_HEADERS.copy()
    headers["Authorization"] = f"Bearer {ftoken}"

    body = {"programSerialNumber": flex_prog_serial}

    results = requests_post(uri, body, headers)

    config_id = None
    for item in results['configs']:
        if item["name"] == os.environ.get("FLEX_CONFIG_NAME"):   
            config_id = item['id']
            break
    return config_id


# This function will be triggered by Pub/Sub
@functions_framework.cloud_event
def ascale_pubsub(cloud_event):
    """Main function"""

    rawd = cloud_event.data["message"]["data"]
    based = base64.b64decode(rawd)
    data = json.loads(based)
    labels = data["resource"]["labels"]
    instance = labels["instance_id"]
    project = labels["project_id"]
    zone = labels["zone"]
    action = data["protoPayload"]["methodName"]
    # print(instance, project, zone)
    credentials=get_credentials()
    key = get_key()
    pubip = get_ip(credentials, instance, project, zone)
    ftoken=fauth()
    config_id = get_flex_configid(ftoken)
    if action == "v1.compute.instances.insert":
        pubip = get_ip(credentials, instance, project, zone)
        serial = entitlements_list(ftoken, config_id)
        activate_flex_entitlement(ftoken, serial)
        flextoken = new_flex_token(ftoken, serial)
        documents = {
            instance: {
                "pubip": pubip,
                "serial": serial
            }
        }
        add_firestore_collection(key, documents)
        vmlicense_download(pubip, flextoken)

    if action == "v1.compute.instances.delete":
        serial = get_firestore_document(key, instance)
        stop_flex_entitlement(ftoken, serial)
        delete_firestore_document(key, instance)

